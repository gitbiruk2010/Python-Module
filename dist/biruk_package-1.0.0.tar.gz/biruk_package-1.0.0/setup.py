from setuptools import setup, find_packages

setup(
    name='biruk_package',
    version='1.0.0',
    author='Biruk Beyene',
    author_email='biruk.beyene@seattlecolleges.edu',
    description='A package that contains a table generator and a file searcher',
    packages=find_packages(),
    install_requires=[],
)
